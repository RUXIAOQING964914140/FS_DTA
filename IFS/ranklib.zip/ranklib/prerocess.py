import pandas as pd
import numpy as np

df = pd.read_csv("davis_train_sam.txt",delimiter=r"\s+",header=None,engine="python")

a = [0,1]
b = [2,3]
data = df[df.columns[a+b]]
data.to_csv("test.txt",sep=" ",header=False,index=False)
